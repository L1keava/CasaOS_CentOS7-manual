#pragma once
static const char MERGERFS_VERSION[] = "2.40.2";
