#pragma once

#include "fs_path.hpp"

#include <vector>

namespace fs
{
  typedef std::vector<fs::Path> PathVector;
}
