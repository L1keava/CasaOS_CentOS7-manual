---
name: Question
about: When you're looking for information or general support
title: ''
labels: investigating, question
assignees: ''

---

For general questions and support please use [GitHub Discussions](https://github.com/trapexit/mergerfs/discussions) or [Discord](https://discord.gg/MpAr69V).
