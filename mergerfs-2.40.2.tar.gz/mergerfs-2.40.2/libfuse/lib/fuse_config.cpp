/*
  ISC License

  Copyright (c) 2023, Antonio SJ Musumeci <trapexit@spawn.link>

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted, provided that the above
  copyright notice and this permission notice appear in all copies.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

#include <string>

static int         g_READ_THREAD_COUNT          = -1;
static int         g_PROCESS_THREAD_COUNT       = -1;
static int         g_PROCESS_THREAD_QUEUE_DEPTH = -1;
static std::string g_PIN_THREADS                = {};


int
fuse_config_get_read_thread_count()
{
  return g_READ_THREAD_COUNT;
}

void
fuse_config_set_read_thread_count(int const v_)
{
  g_READ_THREAD_COUNT = v_;
}

int
fuse_config_get_process_thread_count()
{
  return g_PROCESS_THREAD_COUNT;
}

void
fuse_config_set_process_thread_count(int const v_)
{
  g_PROCESS_THREAD_COUNT = v_;
}

int
fuse_config_get_process_thread_queue_depth()
{
  return g_PROCESS_THREAD_QUEUE_DEPTH;
}

void
fuse_config_set_process_thread_queue_depth(int const v_)
{
  g_PROCESS_THREAD_QUEUE_DEPTH = v_;
}

std::string
fuse_config_get_pin_threads()
{
  return g_PIN_THREADS;
}

void
fuse_config_set_pin_threads(std::string const v_)
{
  g_PIN_THREADS = v_;
}
