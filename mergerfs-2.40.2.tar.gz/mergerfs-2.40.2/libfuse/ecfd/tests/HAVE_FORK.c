#include <sys/types.h>
#include <unistd.h>

int
main(void)
{
  (void)fork;
  
  return 0;
}
