#include <malloc.h>

int
main()
{
  malloc_trim(0);
}
