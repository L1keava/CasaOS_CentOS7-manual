#include <fcntl.h>
#include <sys/stat.h>

int
main(int   argc,
     char *argv[])
{
  (void)utimensat;

  return 0;
}
